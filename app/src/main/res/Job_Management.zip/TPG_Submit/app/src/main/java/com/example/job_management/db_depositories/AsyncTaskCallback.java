package com.example.job_management.db_depositories;

public interface AsyncTaskCallback {
}
