package com.example.job_management;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class ListAdvertActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list_advert);
    }
}