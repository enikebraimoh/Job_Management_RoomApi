package com.example.job_management.db_operations;

public interface JobAdvertDao {
}
