package com.example.job_management;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;


public class JobAdvertActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_job_advert);
    }
}