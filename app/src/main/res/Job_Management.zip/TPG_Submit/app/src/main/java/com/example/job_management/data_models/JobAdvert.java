package com.example.job_management.data_models;

public class JobAdvert {
}
